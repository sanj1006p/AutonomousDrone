def get_data():
    return 0

def get_data_type(str):
    return "m/s"

def get_data_type_(str):
    return "meters per second"