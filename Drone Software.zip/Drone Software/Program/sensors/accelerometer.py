def get_data():
    return 0

def get_data_type():
    return "m/s^2"

def get_data_type_():
    return "meters per second square"