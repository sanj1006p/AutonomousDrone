pitch = 0
yaw = 0
roll = 0

def get_data_pitch():
    return pitch

def get_data_yaw():
    return yaw

def get_data_roll():
    return roll

def get_data():
    '''reutrns yaw, pitch, roll'''
    return yaw, pitch, roll

def get_data_type():
    return "deg"

def get_data_type_():
    return "degree  s"