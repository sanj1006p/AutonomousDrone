from sensors import speedometer as vel
from sensors import accelerometer as accel
from sensors import gyroscope as gyro
import math

class Drone:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0
        self.pitch = gyro.get_data_pitch()
        self.yaw = gyro.get_data_yaw()
        self.roll = gyro.get_data_roll()
        # self.velocity is lateral velocity
        self.velocity = vel.get_data()
        self.velocity_vertical = 0

    def telemetry(self):
        '''returns x, y, z, pitch, yaw, roll, velocity, vertical velocity'''
        #            0       1       2       3           4         5          6              7
        return [self.x, self.y, self.z, self.pitch, self.yaw, self.roll, self.velocity, self.velocity_vertical]

    def coords(self):
        '''returns x, y, z, pitch, yaw'''
        #            0       1       2
        return [self.x, self.z*-1, self.y]

    def evaluate(self, time):
        self.x += (self.velocity*math.cos(math.radians(self.yaw)))*time
        self.z += (self.velocity*math.sin(math.radians(self.yaw)))*time
        self.y += self.velocity_vertical

    def set_location(self, point):
        self.x = point.x
        self.y = point.y
        self.z = point.z