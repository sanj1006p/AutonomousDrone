import matplotlib.pyplot as plt

ax = plt.add_subplot(111, projection="3d")

def display(points):
    ax.plot(points[0], points[1], points[2], color='blue')
    plt.show()