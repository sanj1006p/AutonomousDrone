from pygame.locals import *

arr=[[0],[0],[0]]

def update_points(arrx, data):
    for i in range(3):
        arrx[i].append(data[i])

def dump_points():
    return arr

def execute(drone):
    import drone as d
    import location
    import pygame
    import time
    import turtle
    t = turtle.Turtle()
    t.left(90)
    origin = location.Location(0, 0, 0)
    pygame.init()
    surface = pygame.display.set_mode((800, 600))       #creates the surface to display info and receive input      
    pygame.font.init()
    my_font = pygame.font.SysFont('Lucida Console', 90)    #establish font style
    running = True
    while running:                                      #loop that goes on until we tell it to stop
        surface.fill((0, 0, 0))                         #This part is for displaying information on the screen
        tele = drone.telemetry()
        txt = str(round(tele[0], 2)) + ' ' + str(round(tele[1], 2)) + ' ' + str(round(tele[2], 2))
        coord = my_font.render(str(txt), True, (0, 255, 0))
        surface.blit(coord, (10, 10))
        dir = my_font.render((str(tele[4])+'deg'), True, (0, 255, 0))
        surface.blit(dir, (10, 100))
        dir = my_font.render((str(tele[6])+'m/s'), True, (0, 255, 0))
        surface.blit(dir, (10, 190))
        dir = my_font.render((str(tele[7])+'m/s'), True, (0, 255, 0))
        surface.blit(dir, (10, 280))
        pygame.display.flip()                           #updates screen after changes have been made
        
        for event in pygame.event.get():                #pygame function to receive inputs anytime
            if event.type == KEYDOWN:                   #detects if a key was pressed
                if event.key == K_ESCAPE:               #each condition relates to a key and then we assign function
                    update_points(arr, drone.coords())
                    running = False
                
                if event.key == K_w:
                    drone.velocity+=1
                
                if event.key == K_s:
                    drone.velocity-=1
                
                if event.key == K_d:
                    drone.yaw=(drone.yaw+45)%360
                    t.right(45)
                    update_points(arr, drone.coords())
                
                if event.key == K_a:
                    drone.yaw=(drone.yaw-45)%360
                    t.left(45)
                    update_points(arr, drone.coords())

                if event.key == K_UP:
                    drone.velocity_vertical+=1
                
                if event.key == K_DOWN:
                    drone.velocity_vertical-=1
                
                if event.key == K_x:
                    drone.velocity=0
                    drone.velocity_vertical=0

                if event.key == K_o:
                    drone.set_location(origin)
                    t.goto(0, 0)
                    t.clear()

            elif event.type == QUIT:                       #to exit program at end
                running = False
        sleep_time = 0.1
        time.sleep(sleep_time)                             #time between every update, ideally should be 1 NOTE: evaluate() adjusted for new time
        drone.evaluate(sleep_time)                         #evalutes drone position with relation to velocity and direction
        t.forward(drone.velocity*sleep_time*10)               #updates drawing of drone