from doctest import set_unittest_reportflags
import drone
import control
import visualise

droneInstance = drone.Drone()
control.execute(droneInstance)
visualise.display(control.dump_points())