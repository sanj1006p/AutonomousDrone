go into Program folder and run main.py using Python 3.10 
